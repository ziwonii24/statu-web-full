package minsu.restapi.persistence.dao;

import minsu.restapi.persistence.model.Category1;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Category1Repository extends JpaRepository<Category1, Long> {
}
