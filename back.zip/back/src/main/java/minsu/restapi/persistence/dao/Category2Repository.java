package minsu.restapi.persistence.dao;

import minsu.restapi.persistence.model.Category2;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Category2Repository extends JpaRepository<Category2, Long> {
}
