package minsu.restapi;
/*
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestapiApplicationTests {

    @Test
    void contextLoads() {
    }

}
*/