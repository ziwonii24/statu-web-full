package com.example.test.persistence.dao;


import com.example.test.persistence.model.SubTitle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface SubTitleRepository extends JpaRepository<SubTitle, Long> {

    List<SubTitle> findBySubTitleLike(@Param("subtitle") String subtitle);
}
