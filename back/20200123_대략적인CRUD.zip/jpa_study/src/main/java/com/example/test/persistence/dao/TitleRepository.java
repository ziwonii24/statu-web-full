package com.example.test.persistence.dao;

import com.example.test.persistence.model.Title;
import org.springframework.data.jpa.repository.JpaRepository;


public interface TitleRepository extends JpaRepository<Title, Long> {
}
