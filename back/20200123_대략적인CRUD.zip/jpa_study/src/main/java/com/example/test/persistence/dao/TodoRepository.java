package com.example.test.persistence.dao;

import com.example.test.persistence.model.Todo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TodoRepository extends JpaRepository<Todo, Long> {

    @Query("select t from Todo t where t.today = :today AND t.calenderId = :calenderId ")
    public List<Todo> findByTodayCal(@Param("today") String today, @Param("calenderId") Long calenderId);
}
