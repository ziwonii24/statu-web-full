package com.example.test.persistence.dao;

import com.example.test.persistence.model.SubTitle;
import com.example.test.persistence.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface UserRepository extends JpaRepository<User, Long> {

    boolean existsByNickname(@Param("nickname") String nickname);

    boolean existsByUserMail(@Param("usermail") String usermail);

    void deleteByUserMail(@Param("email") String email);
}
