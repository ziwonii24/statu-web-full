package com.example.test.persistence.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name="user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="id")
    private Long userId;
    private String userMail;
    private String userPassword;

    @Column
    private String nickname;

    private String img;

    @ManyToMany
    @JoinTable(name="user_category",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "category_id"))
    private List<Category> categorys = new ArrayList<>();

    @ManyToMany
    @JoinTable(name="user_sub_category",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "sub_category_id"))
    private List<SubCategory> subCategorys = new ArrayList<>();

    @Temporal(TemporalType.TIMESTAMP)
    private Date regData;
    //사용자 타입
    //@Column(columnDefinition="USER")
    private String userTypeCode;
    //사용자 상태
    //@Column(columnDefinition="USE")
    private String statusCode;

    User(String userMail, String userPassword, String nickname, String img,
         List<Category> categorys, List<SubCategory> subCategory){
        this.userMail=userMail;
        this.userPassword=userPassword;
        this.nickname=nickname;
        this.img=img;
        this.categorys=categorys;
        this.subCategorys=subCategory;

    }

}
