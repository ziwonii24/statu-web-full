package com.example.test.service;

import com.example.test.persistence.dao.CategoryRepository;
import com.example.test.persistence.dao.SubCategoryRepository;
import com.example.test.persistence.model.Category;
import com.example.test.persistence.model.SubCategory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService implements ICategoryService {

    @Autowired
    CategoryRepository categoryRepository;

    @Autowired
    SubCategoryRepository subCategoryRepository;


    @Override
    public List<Category> categoryfindAll() {

        List<Category> categories = categoryRepository.findAll();

        return categories;
    }

    @Override
    public List<SubCategory> subCategoryfindAll() {

        List<SubCategory> subCategories = subCategoryRepository.findAll();

        return subCategories;
    }
}
