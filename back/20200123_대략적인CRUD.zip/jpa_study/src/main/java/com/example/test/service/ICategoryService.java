package com.example.test.service;

import com.example.test.persistence.model.Category;
import com.example.test.persistence.model.SubCategory;

import java.util.List;

public interface ICategoryService {

    List<Category> categoryfindAll();

    List<SubCategory> subCategoryfindAll();

}
