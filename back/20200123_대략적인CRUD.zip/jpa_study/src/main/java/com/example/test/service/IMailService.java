package com.example.test.service;
public interface IMailService {
    //public boolean send(String subject, String text, String from, String to, String filePath);
    public void sendSimpleMessage(String to, String subject, String text);
}
