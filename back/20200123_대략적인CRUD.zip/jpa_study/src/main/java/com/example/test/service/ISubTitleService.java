package com.example.test.service;

import com.example.test.persistence.model.SubTitle;

import java.util.List;
import java.util.Optional;

public interface ISubTitleService {

    List<SubTitle> findAll();

   Optional<SubTitle> findById(Long subTitleId);

    List<SubTitle> findBySubTitle(String subTitle);

    void save(SubTitle subTitle);

    void deleteById(Long subTitleId);
}
