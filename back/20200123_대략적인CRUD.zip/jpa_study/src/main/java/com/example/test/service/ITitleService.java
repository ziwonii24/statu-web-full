package com.example.test.service;

import com.example.test.persistence.model.Title;

import java.util.List;
import java.util.Optional;

public interface ITitleService {

    List<Title> findAll();

    Optional<Title> findById(Long titleId);
}
