package com.example.test.service;

import com.example.test.persistence.model.Todo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ITodoService {

    public List<Todo>findAll();

    public void save(Todo todo);

    public void deleteById(Long todoId);

    public void update(Todo todo);

    public Optional<Todo> findById(Long todoId);

    public List<Todo> findByTodayCal(String today, Long calenderId);
}
