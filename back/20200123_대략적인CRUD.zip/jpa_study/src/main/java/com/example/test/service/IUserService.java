package com.example.test.service;

import com.example.test.persistence.model.User;
import com.example.test.persistence.model.VerificationToken;

import java.util.List;
import java.util.Optional;

public interface IUserService {


    boolean checkMail(String usermail);

    boolean checkNickname(String nickname);

    List<User> findAll();

    Optional<User> findById(Long id);

    void save(User User);

    void deleteByEmail(String email);

    VerificationToken getVerificationToken(String VerificationToken);

    void createVerificationTokenForUser(User user, String token);


}
