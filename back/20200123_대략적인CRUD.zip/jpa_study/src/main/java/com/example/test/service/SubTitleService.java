package com.example.test.service;

import com.example.test.persistence.dao.SubTitleRepository;
import com.example.test.persistence.model.SubTitle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class SubTitleService implements ISubTitleService{

    @Autowired
    SubTitleRepository subTitleRepository;

    @Override
    public List<SubTitle> findAll() {
        return subTitleRepository.findAll();
    }

    @Override
    public Optional<SubTitle> findById(Long subTitleId) {
        return subTitleRepository.findById(subTitleId);
    }

    @Override
    public List<SubTitle> findBySubTitle(String subTitle) {
        return subTitleRepository.findBySubTitleLike('%'+subTitle+'%');
    }

    @Override
    public void save(SubTitle subTitle) {
        subTitleRepository.save(subTitle);
    }

    @Override
    public void deleteById(Long subTitleId) {
        subTitleRepository.deleteById(subTitleId);
    }
}
