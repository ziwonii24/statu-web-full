package com.example.test.service;


import com.example.test.persistence.dao.TitleRepository;
import com.example.test.persistence.model.Title;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class TitleService implements ITitleService {

    @Autowired
    TitleRepository titleRepository;

    @Override
    public List<Title> findAll() {
        return titleRepository.findAll();
    }

    @Override
    public Optional<Title> findById(Long titleId) {
        return titleRepository.findById(titleId);
    }
}
