package com.example.test.service;


import com.example.test.persistence.dao.TodoRepository;
import com.example.test.persistence.model.Todo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class TodoService implements ITodoService{

    @Autowired
    TodoRepository todoRepository;

    @Override
    public List<Todo> findAll() {
        return todoRepository.findAll();
    }

    @Override
    public void save(Todo todo) {
        todoRepository.save(todo);
    }

    @Override
    public void deleteById(Long todoId) {
        todoRepository.deleteById(todoId);
    }

    @Override
    public void update(Todo todo) {
        todoRepository.save(todo);
    }

    @Override
    public Optional<Todo> findById(Long todoId) {
        return todoRepository.findById(todoId);
    }

    @Override
    public List<Todo> findByTodayCal(String today, Long calenderId) {
        return todoRepository.findByTodayCal(today, calenderId);
    }
}
