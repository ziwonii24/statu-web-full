package com.example.test.service;

import com.example.test.persistence.dao.UserRepository;

import com.example.test.persistence.dao.VerificationTokenRepository;
import com.example.test.persistence.model.User;
import com.example.test.persistence.model.VerificationToken;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class UserService implements IUserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private VerificationTokenRepository tokenRepository;



    public static final String TOKEN_INVALID = "invalidToken";
    public static final String TOKEN_EXPIRED = "expired";
    public static final String TOKEN_VALID = "valid";

    public static String QR_PREFIX = "https://chart.googleapis.com/chart?chs=200x200&chld=M%%7C0&cht=qr&chl=";
    public static String APP_NAME = "SpringRegistration";

    // API

    public void save(User user){
        userRepository.save(user);
    }

    @Override
    public void deleteByEmail(String email) {
        System.out.println("check in service");
        System.out.println(email);
        userRepository.deleteByUserMail(email);
        System.out.println("check in after repository");
    }


    public boolean checkMail(String usermail){
        boolean result = userRepository.existsByUserMail(usermail);
        return result;
    }

    public boolean checkNickname(String nickname){
        boolean result = userRepository.existsByUserMail(nickname);
        return result;

    }

    public List<User> findAll(){
        List<User> users =userRepository.findAll();
        return users;
    }

    public Optional<User> findById(Long id){
        Optional<User> user = userRepository.findById(id);
        return user;
    }


    @Override
    public VerificationToken getVerificationToken(final String VerificationToken) {
        return tokenRepository.findByToken(VerificationToken);
    }

    @Override
    public void createVerificationTokenForUser(final User user, final String token) {
        final VerificationToken myToken = new VerificationToken(token, user);
        tokenRepository.save(myToken);
    }

}
