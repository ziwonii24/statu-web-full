package com.example.test.web.controller;

import com.example.test.persistence.model.Category;
import com.example.test.persistence.model.SubCategory;
import com.example.test.service.ICategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class CategoryController {

    @Autowired
    ICategoryService iCategoryService;


    @GetMapping("/categorys")
    List<Category> categorys(){
        List<Category> list = iCategoryService.categoryfindAll();
        return  list;
    }

    @GetMapping("/subcategorys")
    List<SubCategory> subCategories(){
        List<SubCategory> list = iCategoryService.subCategoryfindAll();
        return  list;
    }
}
