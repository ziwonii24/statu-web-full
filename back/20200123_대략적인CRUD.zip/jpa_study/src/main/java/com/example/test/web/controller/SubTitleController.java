package com.example.test.web.controller;

import com.example.test.persistence.model.SubTitle;
import com.example.test.persistence.dao.SubTitleRepository;
import com.example.test.service.ISubTitleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class SubTitleController {

    @Autowired
    ISubTitleService iSubTitleService;

    @GetMapping("/subTitle")
    public List<SubTitle> findAll(){
        return iSubTitleService.findAll();
    }

    @GetMapping("/subTitle/{subTitleId}")
    public Optional<SubTitle> subTitleById(@PathVariable Long subTitleId){
        return iSubTitleService.findById(subTitleId);
    }

    @GetMapping("/subTitle/content/{subTitle}")
    public List<SubTitle> subTitleByContent(@PathVariable String subTitle){
        return iSubTitleService.findBySubTitle(subTitle);
    }

    @PostMapping("/subTitle")
    public void stInsert(@RequestBody SubTitle subTitle){
        iSubTitleService.save(subTitle);
    }

    @PutMapping("/subTitle")
    public void stUpdate(@RequestBody SubTitle subTitle){
        //todo

    }

    @DeleteMapping("/subTitle/{subTitleId}")
    public void stDelete(@PathVariable Long subTitleId){
        iSubTitleService.deleteById(subTitleId);
    }
}
