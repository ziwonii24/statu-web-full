package com.example.test.web.controller;

import com.example.test.persistence.model.Title;
import com.example.test.persistence.dao.TitleRepository;
import com.example.test.service.ITitleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
public class TitleController {

    @Autowired
    ITitleService iTitleService;

    @GetMapping("/title")
    public List<Title> title(){
        return iTitleService.findAll();
    }

    @GetMapping("/title/{titleId}")
    public Optional<Title> titleById(@PathVariable Long titleId){
        return  iTitleService.findById(titleId);
    }
}
