package com.example.test.web.controller;

import com.example.test.persistence.model.Todo;
import com.example.test.persistence.model.User;
import com.example.test.service.ITodoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class TodoController {

    @Autowired
    ITodoService iTodoService;

    @ExceptionHandler
    public Map<String, String> errorHandler(Exception e){
        Map<String, String> map = new HashMap<>();
        map.put("result", "false");
        return map;
    }


    @GetMapping("/todo")
    public List<Todo> findAll(){
        return iTodoService.findAll();
    }

    @GetMapping("/todo/{today}/{calenderId}")
    public List<Todo> findByTodoyCal(@PathVariable String today, @PathVariable Long calenderId){
        return iTodoService.findByTodayCal(today,calenderId);
    }

    @DeleteMapping("/todo/{todoId}")
    public Map<String,String> deleteById(@PathVariable Long todoId){

        Map<String, String> map = new HashMap<>();
        iTodoService.deleteById(todoId);
        map.put("result", "success");
        return map;
    }

    @PostMapping("/todo")
    public Map<String,String> insertTodo(@RequestBody Todo todo){
        Map<String, String> map = new HashMap<>();
        iTodoService.save(todo);
        map.put("result", "success");
        return map;

    }

    @PutMapping("/todo")
    public Map<String,String> updateTodo(@RequestBody Todo todo){
        Map<String, String> map = new HashMap<>();
        iTodoService.update(todo);
        map.put("result", "success");
        return map;

    }


}
