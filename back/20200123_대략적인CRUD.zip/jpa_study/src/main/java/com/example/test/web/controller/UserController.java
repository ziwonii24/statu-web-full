package com.example.test.web.controller;

import com.example.test.persistence.model.User;
import com.example.test.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
public class UserController {

    @Autowired
    IUserService iUserService;

    @ExceptionHandler
    public Map<String, String> errorHandler(Exception e){
        Map<String, String> map = new HashMap<>();
        map.put("result", "false");
        return map;
    }

    @GetMapping("/user")
    public List<User> findAll(){
        return iUserService.findAll();
    }

    @GetMapping("/user/{userId}")
    public Optional<User> findById(@PathVariable Long userId){
        return iUserService.findById(userId);
    }

    @GetMapping("/user/checkmail/{usermail}")
    public Map<String,String> checkmail(@PathVariable String usermail){

        Map<String,String> map = new HashMap<>();
        if(iUserService.checkMail(usermail)){
            map.put("result", "true");
        }else{
            map.put("result", "false");
        }
        return map;
    }

    @GetMapping("/user/checkname/{nickname}")
    public Map<String,String> checknickname(@PathVariable String nickname){
        Map<String,String> map = new HashMap<>();
        if(iUserService.checkNickname(nickname)){
            map.put("result", "true");
        }else{
            map.put("result", "false");
        }
        return map;
    }


    //user 객체 받아올때 category id값만 보내주고 name은 안줘도 입력잘댐
    @PostMapping("/user")
    public Map<String,String> insertUser(@RequestBody User user){
        Map<String, String> map = new HashMap<>();
        iUserService.save(user);
        map.put("result", "success");
        return map;

    }


    @DeleteMapping("/user/{email}")
    public Map<String,String> deleteUser(@PathVariable String email){
        Map<String,String> map = new HashMap<>();
        iUserService.deleteByEmail(email);
        System.out.println(email);
        map.put("result", "success");
        return map;

    }
}
